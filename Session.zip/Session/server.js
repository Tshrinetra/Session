const express = require("express");
const app = express();
const session = require("express-session");
app.use(express.urlencoded({extended:true}))
app.use(session({
      secret: "same new",
      saveUninitilized: false,
      resave: true,
})
)
function auth(req, res, next) {
      if (!req.session.name && !req.session.password)
            res.sendFile(__dirname + "/login.html");
      else 
      next();
}
app.get("/home", auth, (req, res) => {
      if(req.session.role == "user")
      res.sendFile(__dirname + "/page.html");
else
res.sendFile(__dirname + "/admin.html");
})
app.get("/login", (req, res) => {
      res.sendFile(__dirname + "/login.html");
})
app.post("/logindata", (req, res) => {
      console.log(req.body);
req.session.name = req.body.name;
req.session.password = req.body.password;
req.session.role = req.body.role;
      res.redirect("/home");
})
app.get("/logout",(req,res)=>{
      req.session.destroy();
      res.redirect("/home");
})
app.listen(3000,(err)=>{
      console.log("start");
})
